package com.anson.module1.globalvariables;

/**
 * Global variables for colours of the shapes.
 */
public enum Colour {
    RED, GREEN, BLUE, NONE;
}
