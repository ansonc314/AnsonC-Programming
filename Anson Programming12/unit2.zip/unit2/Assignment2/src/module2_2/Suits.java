package module2_2;

public enum Suits {
    SPADES, HEARTS, CLUBS, DIAMONDS;
}
