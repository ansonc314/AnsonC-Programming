package module2_1;

public enum PlanetType {
    EXOPLANET, DWARF, GAS_GIANT, ICE_GIANT, NONE;
}
