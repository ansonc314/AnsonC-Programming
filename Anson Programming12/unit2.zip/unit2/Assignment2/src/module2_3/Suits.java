package module2_3;

public enum Suits {
    SPADES, HEARTS, CLUBS, DIAMONDS;
}
