package com.example.globalVariables;

public class SystemInfo {
    public static String databaseName = "signInDatabase";
    public static String csvFilename = "csvDatabase";
    public static String databaseTableName = "SIGNINTABLE";


}
