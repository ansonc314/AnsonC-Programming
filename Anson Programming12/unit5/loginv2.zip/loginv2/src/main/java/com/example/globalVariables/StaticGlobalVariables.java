package com.example.globalVariables;

public class StaticGlobalVariables {
    public static String currentUser ; // this variable keep tracks of the Full Name of the user who log-in

}
