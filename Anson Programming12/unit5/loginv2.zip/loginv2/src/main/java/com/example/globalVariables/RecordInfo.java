package com.example.globalVariables;
public class RecordInfo {
    public static int noHeader=3;
    public static String[] header = new String[]{"UserName","Password","FullName"}; // columns of the users records

}
